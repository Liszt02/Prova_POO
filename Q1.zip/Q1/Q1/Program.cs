﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Digite seu nome: ");
                string pass = Console.ReadLine();
                NomeProprio nome = new NomeProprio(pass);
                Console.WriteLine("Seu nome em publicações é: ");
                nome.ImprimeNomePaper();
                Console.ReadLine();
            }
        }
    }
}
