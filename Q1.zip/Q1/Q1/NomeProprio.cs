﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
    internal class NomeProprio
    {
        public string nome_completo;
        public string nome_paper;

        //fim dos atributos
        
        public NomeProprio(string nome_completo)
        {
            this.nome_completo= nome_completo;
            string[] list = nome_completo.Split(' ');
            this.nome_paper = list[list.Length-1];
            if(list.Length > 1) {
                this.nome_paper += ",";
                for(int i=0;i<list.Length-1;i++) {
                    this.nome_paper += " ";
                    if (list[i][1] == '.' || i==0) this.nome_paper+=(list[i]);
                    else
                    {
                        this.nome_paper += list[i][0];
                        this.nome_paper += ".";
                    }
                }
            }
        }
        public string Nome_completo { get => nome_completo; set => nome_completo = value; }
        public string Nome_paper { get => nome_paper; set => nome_paper = value; }

        // fim dos getters e setters

        public void ImprimeNomePaper()
        {
            Console.WriteLine(this.Nome_paper);
        }

        //fim dos metodos
    }
}
