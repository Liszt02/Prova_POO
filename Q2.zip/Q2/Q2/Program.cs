﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            NumComplexo z1 = new NumComplexo(1,1);
            NumComplexo z2 = new NumComplexo(3,-1);

            Console.WriteLine("Soma de z1 e z2: ");
            (z1.Soma(z2)).ImprimeFormaPolar();

            Console.WriteLine("Produto de z1 e z2: ");
            (z1.Vezes(z2)).ImprimeFormaPolar();

            Console.ReadLine();
        }
    }
}
