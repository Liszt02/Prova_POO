﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    internal class NumComplexo
    {
        public double re;
        public double im;

        //fim dos atributos

        public NumComplexo()
        {
            this.re = 0;
            this.im = 0;
        }

        public NumComplexo(double x, double y)
        {
            this.re = x;
            this.im = y;
        }

        public double Re { get => re; set => re = value; }
        public double Im { get => im; set => im = value; }

        //  fim dos getters e setters

        public NumComplexo Soma(NumComplexo obj)
        {
            NumComplexo v_new = new NumComplexo();
            v_new.Re = this.Re+obj.Re;
            v_new.Im = this.Im+obj.Im;
            return v_new;
        }

        public NumComplexo Vezes(NumComplexo obj)
        {
            NumComplexo v_new = new NumComplexo();
            v_new.Re = this.Re*obj.Re - this.Im*obj.Im;
            v_new.Im = this.Re*obj.Im + this.Im*obj.Re;
            return v_new;
        }
        public double Modulo()
        {
            return Math.Sqrt(this.Re * this.Re + this.Im * this.Im);
        }

        public double Argumento()
        {
            return Math.Atan2(this.Im,this.Re) * (180 / Math.PI);
        }

        public void ImprimeFormaPolar()
        {
            Console.WriteLine(this.Modulo() + " | " + this.Argumento() + "°");
        }

        // fim dos metodos
    }
}
